# Algoritmos de Ordenação em C — Trabalho Prático

Implementação e análise empírica de 6 algoritmos de ordenação (3 básicos +
3 avançados), com testes, cobertura de código (`gcov`) e profiling de
desempenho (`gprof`).

## 👥 Integrantes

| Nome | E-mail | Responsabilidade principal |
| --- | --- | --- |
| David Oliveira Diniz | diniz.david@discente.ufma.br | Algoritmos básicos (bubble, selection, insertion), testes, Makefile, cobertura (`gcov`), `cppcheck` e documentação |
| Gustavo Henrique de Souza Sudre Costa | gustavo.sudre@discente.ufma.br | Algoritmos avançados (merge, quick, heap), `main.c` e profiling (`gprof`) |

## 📁 Estrutura

```
ordenacao-trio/
├── README.md
├── Makefile
├── src/
│   ├── sort.h                 # Assinaturas padrão dos 6 algoritmos
│   ├── basicos/                # bubble.c, selection.c, insertion.c
│   ├── avancados/               # merge.c, quick.c, heap.c
│   └── main.c                  # Menu interativo + benchmark
├── tests/
│   └── test_basic.c            # 6 casos de teste por algoritmo (36 no total)
├── docs/
│   ├── cobertura.md            # Relatório gcov + análise (100% de cobertura)
│   ├── perfil.md               # Interpretação do profiling + benchmark por cenário
│   ├── perfil_bruto.txt        # Saída bruta do gprof
│   ├── gcov_raw/                # Saída bruta do gcov por arquivo
│   ├── cppcheck_raw.txt        # Saída do cppcheck
│   └── uso-ia.md               # Transparência sobre uso de IA
└── .gitignore
```

## 🔢 Algoritmos implementados

| Categoria | Algoritmo | Complexidade (pior caso) | Estável | In-place |
| --- | --- | --- | --- | --- |
| Básico | Bubble Sort | O(n²) | Sim | Sim |
| Básico | Selection Sort | O(n²) | Não | Sim |
| Básico | Insertion Sort | O(n²) | Sim | Sim |
| Avançado | Merge Sort | O(n log n) | Sim | Não |
| Avançado | Quick Sort (pivô = último) | O(n²) | Não | Sim |
| Avançado | Heap Sort | O(n log n) | Não | Sim |

Todas as funções seguem a assinatura `void algoritmoSort(int v[], int n);`.

## 🚀 Como compilar e rodar

```bash
# Compilar o programa principal
make all
./sort_main

# Rodar o benchmark direto, sem menu
./sort_main bench

# Rodar a suíte de testes (36 casos)
make test

# Gerar cobertura de código
make coverage
gcov -o src/basicos src/basicos/*.c
gcov -o src/avancados src/avancados/*.c

# Gerar profiling de desempenho
make profile
cat docs/perfil_bruto.txt

# Rodar análise estática
make cppcheck

# Limpar artefatos gerados
make clean
```

### Checklist de entrega (rodar antes de cada `push`)

```bash
make clean && make all && make test && make coverage && make profile
```

## ✅ Resultados obtidos

- **Funcionalidade:** 6/6 algoritmos compilam sem warnings (`-Wall -Wextra
  -std=c11`) e ordenam corretamente em todos os cenários testados.
- **Testes:** 36/36 testes passando (`make test`) — 6 cenários por algoritmo:
  aleatório, ordenado, invertido, com duplicatas, `n=1` e `n=0`.
- **Cobertura:** **100%** de linhas executadas em todos os 6 arquivos de
  algoritmos (meta da rubrica era ≥70%). Detalhes em
  [`docs/cobertura.md`](docs/cobertura.md).
- **Profiling:** análise comparativa de tempo via `gprof` e benchmark próprio
  por cenário (aleatório/ordenado/invertido) em
  [`docs/perfil.md`](docs/perfil.md) — destaque para o melhor caso O(n) do
  Bubble Sort otimizado e o pior caso O(n²) do Quick Sort com vetor já
  ordenado.
- **Qualidade estática:** `cppcheck` sem erros críticos, apenas avisos de
  estilo (escopo de variável). Saída completa em
  [`docs/cppcheck_raw.txt`](docs/cppcheck_raw.txt).

## 🤖 Uso de IA

Usamos Claude como apoio para gerar implementações de referência, explicar
conceitos (ex: por que Quick Sort degrada com pivô fixo) e revisar o
Makefile. Todo o código foi compilado, testado e discutido pela dupla antes da
entrega. Detalhes completos, incluindo prompts usados, em
[`docs/uso-ia.md`](docs/uso-ia.md).
