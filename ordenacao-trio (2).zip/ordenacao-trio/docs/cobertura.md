# 📊 Relatório de Cobertura de Código (gcov)

## Como gerar

```bash
make coverage
gcov -o src/basicos src/basicos/*.c
gcov -o src/avancados src/avancados/*.c
```

Os arquivos `.c.gcov` resultantes estão salvos em `docs/gcov_raw/` para consulta,
junto com a saída completa do comando acima.

## Resultado por arquivo

| Arquivo | Linhas executáveis | Cobertura | Status |
| --- | --- | --- | --- |
| `src/basicos/bubble.c` | 12 | **100.00%** | ✅ |
| `src/basicos/selection.c` | 11 | **100.00%** | ✅ |
| `src/basicos/insertion.c` | 9 | **100.00%** | ✅ |
| `src/avancados/merge.c` | 41 | **100.00%** | ✅ |
| `src/avancados/quick.c` | 24 | **100.00%** | ✅ |
| `src/avancados/heap.c` | 24 | **100.00%** | ✅ |
| **Total** | **121** | **100.00%** | ✅ |

A meta da rubrica era **≥70%** de cobertura. Atingimos **100%** em todos os
arquivos de algoritmos porque a suíte de testes (`tests/test_basic.c`) cobre,
para cada algoritmo, seis cenários: vetor aleatório, vetor já ordenado, vetor
invertido, vetor com duplicatas, vetor de um elemento (`n=1`) e vetor vazio
(`n=0`).

## Por que os casos de borda importavam

Sem os casos `n=0` e `n=1`, algumas linhas ficariam sem cobertura:

- Em `bubbleSort`, o laço externo `for (i = 0; i < n - 1; i++)` nunca executa
  o corpo quando `n <= 1`, então testar apenas vetores "normais" deixaria essa
  condição de contorno sem verificação.
- Em `mergeSort` e `quickSort`, a guarda `if (n > 1)` em torno da chamada
  recursiva só é exercitada (no ramo falso) pelos casos `n=0` e `n=1`.
- O vetor com duplicatas foi importante para o `quickSort`, garantindo que o
  particionamento (`v[j] <= pivo`) trate corretamente elementos iguais ao
  pivô, e para o `mergeSort`, validando o desempate `L[i] <= R[j]` no merge.

## Cobertura de branches (decisões)

Rodando com `-b`:

```bash
gcov -b -o src/avancados src/avancados/quick.c
```

O `quickSort` é o algoritmo com mais branches relevantes (condição do laço de
partição, comparação com o pivô, condição de recursão). Como os testes
incluem vetor aleatório, ordenado, invertido e com duplicatas, todos os
ramos de decisão de `partition` e `quickSortRec` foram exercitados — inclusive
o pior caso (vetor já ordenado), que é justamente o cenário que estressa mais
chamadas recursivas no Quick Sort com pivô fixo no último elemento.

## Trecho de exemplo (`bubble.c.gcov`)

```text
        6:    9:void bubbleSort(int v[], int n) {
        -:   10:    int i, j, tmp;
        -:   11:    int trocou;
        -:   12:
       27:   13:    for (i = 0; i < n - 1; i++) {
       24:   14:        trocou = 0;
      149:   15:        for (j = 0; j < n - i - 1; j++) {
      125:   16:            if (v[j] > v[j + 1]) {
       85:   17:                tmp = v[j];
       85:   18:                v[j] = v[j + 1];
       85:   19:                v[j + 1] = tmp;
       85:   20:                trocou = 1;
```

O contador `6:` na linha 9 confirma que `bubbleSort` foi chamado 6 vezes (uma
por caso de teste). Nenhuma linha aparece com `#####`, ou seja, nenhum trecho
do algoritmo ficou sem execução.

## Limitações conhecidas

- A cobertura mede **execução de linhas/branches**, não corretude. Por isso
  ela é usada em conjunto com `make test`, que valida o resultado (vetor
  ordenado) de cada execução.
- `main.c` (menu interativo) não está incluído na medição de cobertura porque
  depende de entrada via `scanf`; ele é testado manualmente (ver checklist em
  `README.md`).
