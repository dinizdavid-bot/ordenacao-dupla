# ⏱️ Relatório de Profiling e Análise de Desempenho (gprof)

## Como gerar

```bash
make profile
cat docs/perfil_bruto.txt
```

O alvo `profile` compila com `-pg -O0` (sem otimização, conforme recomendado
no enunciado — otimização do compilador distorce a medição), roda o
benchmark interno (`./sort_profile bench`, n = 8000, vetor aleatório) e gera
`docs/perfil_bruto.txt` com o flat profile e o call graph completos.

## Flat profile (n = 8000, vetor aleatório)

| Função | % tempo | Tempo próprio (s) | Chamadas |
| --- | --- | --- | --- |
| `bubbleSort` | 53.57% | 0.15 | 1 |
| `selectionSort` | 28.57% | 0.08 | 1 |
| `insertionSort` | 17.86% | 0.05 | 1 |
| `mergeSort`, `quickSort`, `heapSort` | ~0.00% | < 0.01 | 1 cada |

**Leitura direta:** com n = 8000, os três algoritmos O(n²) (bubble, selection,
insertion) consomem **100% do tempo amostrado** do programa. Os três
algoritmos O(n log n) somados não aparecem nem com uma amostra — `gprof`
contabiliza por amostragem periódica (a cada 0.01s) e suas execuções foram
rápidas demais para serem capturadas, o que por si só já é uma evidência da
diferença de ordem de grandeza.

Isso bate exatamente com o que a teoria prevê: para n = 8000,
n² = 64.000.000 comparações em potencial, contra n log₂n ≈ 104.000 — quase
três ordens de magnitude de diferença.

## Call graph: o que ele revela

O call graph (seção `index % time` em `perfil_bruto.txt`) mostra que:

- `bubbleSort`, `selectionSort` e `insertionSort` não chamam nenhuma função
  auxiliar — todo custo é "self" (tempo próprio), confirmando que são
  implementações iterativas simples sem overhead de chamadas.
- `heapSort` aparece com **milhares** de chamadas para `heapify` (≈3.000 para
  n=8.000, já que `heapify` é chamado uma vez na construção do heap e n-1
  vezes na extração), e `heapify` se chama recursivamente milhares de vezes
  adicionais — mas ainda assim o tempo total é desprezível, mostrando que o
  custo por chamada é muito pequeno (O(log n) por chamada).
- `quickSort` → `quickSortRec` mostra recursão com ~2.600 chamadas internas
  para n=8.000, compatível com profundidade média O(log n) e ~n chamadas
  totais ao particionamento.
- `mergeSort` → `mergeSortRec` → `merge` mostra o padrão clássico de
  "dividir" (chamadas recursivas) e depois "conquistar" (uma chamada a
  `merge` por nó da árvore de recursão).
- A função `troca` aparece duas vezes na tabela (uma para o `troca` usado em
  `quick.c` e outra para o `troca` usado em `heap.c`) porque ambas são
  `static` — o gprof as distingue como símbolos diferentes mesmo com nomes
  iguais.

## Benchmark complementar: tempo por cenário e tamanho

Além do profiling com `gprof`, rodamos um benchmark dedicado variando
**tamanho do vetor** (1.000 / 5.000 / 10.000) e **cenário inicial**
(aleatório / já ordenado / invertido), medindo com `clock()`:

| Algoritmo | n=10.000 aleatório | n=10.000 ordenado | n=10.000 invertido |
| --- | ---: | ---: | ---: |
| Bubble Sort | 0.2178 s | **0.000009 s** | 0.2761 s |
| Selection Sort | 0.1216 s | 0.1221 s | 0.1212 s |
| Insertion Sort | 0.0153 s | **0.000009 s** | 0.0311 s |
| Merge Sort | 0.00109 s | 0.00050 s | 0.00053 s |
| Quick Sort | 0.00057 s | **0.0405 s** | 0.0347 s |
| Heap Sort | 0.00053 s | 0.00045 s | 0.00045 s |

### Achados mais relevantes

1. **Bubble Sort com vetor já ordenado é quase instantâneo** (0.000009s):
   nossa implementação tem a otimização da flag `trocou`, que interrompe o
   laço externo assim que uma passada completa não realiza trocas — o
   melhor caso vira O(n) em vez de O(n²).

2. **Insertion Sort também se beneficia muito de entrada quase ordenada**,
   pelo mesmo motivo teórico (cada elemento já está perto da posição final,
   então o laço interno `while` quase nunca desloca nada).

3. **Selection Sort não melhora em nenhum cenário** (~0.12s nos três casos):
   ele sempre varre o restante do vetor para achar o mínimo,
   independentemente da ordem de entrada — é O(n²) garantido, sem melhor
   caso. Esse é o contraste mais didático do experimento.

4. **Quick Sort é o único algoritmo avançado que piora muito num cenário
   específico**: com vetor já ordenado, nosso pivô (sempre o último
   elemento) gera partições completamente desbalanceadas, degradando para
   O(n²) — visível nos 0.04s vs. 0.0006s do caso aleatório, quase 70x mais
   lento. Isso confirma exatamente a limitação teórica do esquema de Lomuto
   com pivô fixo.

5. **Merge Sort e Heap Sort são os mais previsíveis**: tempo praticamente
   constante entre os três cenários, como esperado de algoritmos O(n log n)
   garantido (sem pior caso dependente da entrada).

## Conclusão

Os dados de `gprof` (profiling por amostragem) e do benchmark dedicado
(medição direta por cenário) contam a mesma história por ângulos diferentes:
a escolha do algoritmo importa muito mais que micro-otimizações de código
quando o tamanho da entrada cresce, e a *escolha do pivô* no Quick Sort é um
detalhe de implementação com impacto prático real — não apenas teórico.
