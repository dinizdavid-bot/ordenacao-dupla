# 🤖 Uso de Ferramentas de IA no Projeto

## Ferramentas Utilizadas
- [ ] ChatGPT / GPT-4o
- [ ] GitHub Copilot
- [x] Claude / Gemini
- [ ] Outra: _______________

## Como Usamos (exemplos reais)

| Prompt / Solicitação | O que a IA gerou | O que adaptamos/validamos |
|----------------------|------------------|---------------------------|
| "Implemente os 6 algoritmos de ordenação com a assinatura `void algoritmoSort(int v[], int n)`" | Código completo de bubble, selection, insertion, merge, quick e heap sort | Compilamos com `-Wall -Wextra -std=c11` e confirmamos zero warnings; rodamos `make test` (36/36 casos) antes de aceitar qualquer arquivo |
| "Explique a diferença entre o esquema de particionamento de Lomuto e Hoare no Quick Sort" | Explicação teórica das duas estratégias | Decidimos usar Lomuto (pivô = último elemento) por ser mais didático; documentamos no código que esse pivô gera pior caso O(n²) em vetores já ordenados |
| "Por que o Quick Sort ficou mais lento que Merge Sort no benchmark com vetor ordenado?" | Explicação de que pivô fixo no último elemento causa partições desbalanceadas em entrada ordenada | Validamos rodando o benchmark por cenário (`aleatorio`/`ordenado`/`invertido`) e confirmamos empiricamente: Quick Sort foi ~70x mais lento no cenário ordenado vs. aleatório para n=10.000 |
| "Gere casos de teste cobrindo bordas (n=0, n=1, duplicatas)" | Sugestão de 6 cenários por algoritmo | Rodamos `make coverage` e conferimos que sem os casos de borda (`n=0`, `n=1`) algumas linhas de guarda (`if (n > 1)` em merge/quick) ficavam sem cobertura — então mantivemos esses casos |
| "Por que `gprof` mostra 0% de tempo para os algoritmos O(n log n)?" | Explicação sobre amostragem periódica do gprof (a cada 0.01s) não capturar execuções muito rápidas | Aumentamos o tamanho do benchmark de profiling de 2.000 para 8.000 elementos para tornar a diferença entre O(n²) e O(n log n) visível no flat profile |
| "Revise o Makefile, os alvos `coverage` e `profile` não estavam batendo com a estrutura `src/basicos/` e `src/avancados/`" | Makefile ajustado com compilação por objeto e paths corretos | Rodamos `make clean && make all && make test && make coverage && make profile` na íntegra antes de aceitar, conforme checklist do enunciado |

## Validação & Domínio
- [x] Compilamos e rodamos todo código gerado ou sugerido
- [x] Todos conseguem explicar o funcionamento de cada algoritmo em 2 minutos
- [x] Não submetemos blocos inteiros sem revisão linha a linha

## Reflexão Final

A IA acelerou bastante a parte de "boilerplate" — escrever as seis
implementações clássicas, montar a suíte de testes e estruturar o Makefile
com os alvos de `coverage` e `profile`. Isso liberou tempo do grupo para focar
no que realmente importa para o aprendizado: entender *por que* o Quick Sort
degrada para O(n²) com pivô ruim em entrada ordenada, e *por que* o Selection
Sort não tem melhor caso (sempre varre o vetor inteiro procurando o mínimo,
não importa a ordem de entrada). Esses dois pontos só ficaram claros depois
de rodarmos os benchmarks por cenário e comparar os números — a IA explicou a
teoria, mas a validação empírica (e a discussão em grupo sobre os resultados)
foi o que fixou o conceito. O maior cuidado que tomamos foi não aceitar
números ou afirmações da IA sem rodar o código nós mesmos: em um momento a
ferramenta sugeriu testar com vetores pequenos (n=2000) para o profiling, e
percebemos que isso escondia a diferença de desempenho entre os algoritmos —
tivemos que aumentar o tamanho para que o `gprof` mostrasse algo relevante.
