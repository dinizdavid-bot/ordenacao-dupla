#include "../sort.h"

/*
 * Heap Sort
 * Complexidade: O(n log n) em todos os casos
 * Estável: não
 * In-place: sim
 */
static void troca(int *a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

/* Restaura a propriedade de max-heap na subárvore com raiz no índice i */
static void heapify(int v[], int n, int i) {
    int maior = i;
    int esq = 2 * i + 1;
    int dir = 2 * i + 2;

    if (esq < n && v[esq] > v[maior]) {
        maior = esq;
    }

    if (dir < n && v[dir] > v[maior]) {
        maior = dir;
    }

    if (maior != i) {
        troca(&v[i], &v[maior]);
        heapify(v, n, maior);
    }
}

void heapSort(int v[], int n) {
    int i;

    /* Constrói o max-heap */
    for (i = n / 2 - 1; i >= 0; i--) {
        heapify(v, n, i);
    }

    /* Extrai elementos do heap um a um */
    for (i = n - 1; i > 0; i--) {
        troca(&v[0], &v[i]);
        heapify(v, i, 0);
    }
}
