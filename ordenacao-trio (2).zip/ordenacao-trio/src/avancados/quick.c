#include "../sort.h"

/*
 * Quick Sort
 * Complexidade: O(n log n) em média, O(n^2) no pior caso (vetor já ordenado com pivô ruim)
 * Estável: não
 * In-place: sim (usa pilha de recursão)
 *
 * Pivô escolhido: último elemento (esquema de Lomuto).
 */
static void troca(int *a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

static int partition(int v[], int baixo, int alto) {
    int pivo = v[alto];
    int i = baixo - 1;
    int j;

    for (j = baixo; j < alto; j++) {
        if (v[j] <= pivo) {
            i++;
            troca(&v[i], &v[j]);
        }
    }
    troca(&v[i + 1], &v[alto]);
    return i + 1;
}

static void quickSortRec(int v[], int baixo, int alto) {
    if (baixo < alto) {
        int pi = partition(v, baixo, alto);

        quickSortRec(v, baixo, pi - 1);
        quickSortRec(v, pi + 1, alto);
    }
}

void quickSort(int v[], int n) {
    if (n > 1) {
        quickSortRec(v, 0, n - 1);
    }
}
