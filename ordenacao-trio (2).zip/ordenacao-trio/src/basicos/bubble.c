#include "../sort.h"

/*
 * Bubble Sort
 * Complexidade: O(n^2) no pior e médio caso, O(n) no melhor caso (com flag de otimização)
 * Estável: sim
 * In-place: sim
 */
void bubbleSort(int v[], int n) {
    int i, j, tmp;
    int trocou;

    for (i = 0; i < n - 1; i++) {
        trocou = 0;
        for (j = 0; j < n - i - 1; j++) {
            if (v[j] > v[j + 1]) {
                tmp = v[j];
                v[j] = v[j + 1];
                v[j + 1] = tmp;
                trocou = 1;
            }
        }
        /* Otimização: se não houve troca, o vetor já está ordenado */
        if (!trocou) {
            break;
        }
    }
}
