#include "../sort.h"

/*
 * Insertion Sort
 * Complexidade: O(n^2) no pior/médio caso, O(n) no melhor caso (vetor quase ordenado)
 * Estável: sim
 * In-place: sim
 */
void insertionSort(int v[], int n) {
    int i, j, chave;

    for (i = 1; i < n; i++) {
        chave = v[i];
        j = i - 1;

        while (j >= 0 && v[j] > chave) {
            v[j + 1] = v[j];
            j--;
        }
        v[j + 1] = chave;
    }
}
