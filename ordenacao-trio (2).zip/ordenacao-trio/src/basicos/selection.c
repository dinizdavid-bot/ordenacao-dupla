#include "../sort.h"

/*
 * Selection Sort
 * Complexidade: O(n^2) em todos os casos
 * Estável: não (na implementação clássica por troca)
 * In-place: sim
 */
void selectionSort(int v[], int n) {
    int i, j, idxMenor, tmp;

    for (i = 0; i < n - 1; i++) {
        idxMenor = i;
        for (j = i + 1; j < n; j++) {
            if (v[j] < v[idxMenor]) {
                idxMenor = j;
            }
        }
        if (idxMenor != i) {
            tmp = v[i];
            v[i] = v[idxMenor];
            v[idxMenor] = tmp;
        }
    }
}
