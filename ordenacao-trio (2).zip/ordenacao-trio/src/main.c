#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sort.h"

#define TAM_PADRAO 8000

typedef struct {
    const char *nome;
    void (*funcao)(int[], int);
} Algoritmo;

static void gerarVetorAleatorio(int v[], int n, int semente) {
    int i;
    srand((unsigned int) semente);
    for (i = 0; i < n; i++) {
        v[i] = rand() % 100000;
    }
}

static void copiarVetor(const int origem[], int destino[], int n) {
    memcpy(destino, origem, n * sizeof(int));
}

static int estaOrdenado(const int v[], int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        if (v[i] > v[i + 1]) {
            return 0;
        }
    }
    return 1;
}

static void imprimirVetor(const int v[], int n) {
    int i;
    int limite = n < 20 ? n : 20;

    for (i = 0; i < limite; i++) {
        printf("%d ", v[i]);
    }
    if (n > 20) {
        printf("...");
    }
    printf("\n");
}

static void executarBenchmark(int tamanho) {
    Algoritmo algoritmos[] = {
        {"Bubble Sort",    bubbleSort},
        {"Selection Sort", selectionSort},
        {"Insertion Sort", insertionSort},
        {"Merge Sort",     mergeSort},
        {"Quick Sort",     quickSort},
        {"Heap Sort",      heapSort}
    };
    int numAlgoritmos = sizeof(algoritmos) / sizeof(algoritmos[0]);
    int *original = (int *) malloc(tamanho * sizeof(int));
    int *copia = (int *) malloc(tamanho * sizeof(int));
    int i;

    gerarVetorAleatorio(original, tamanho, 42);

    printf("=== Benchmark com n = %d elementos ===\n\n", tamanho);
    printf("%-18s %12s %10s\n", "Algoritmo", "Tempo (s)", "Status");
    printf("---------------------------------------------\n");

    for (i = 0; i < numAlgoritmos; i++) {
        clock_t inicio, fim;
        double tempoGasto;

        copiarVetor(original, copia, tamanho);

        inicio = clock();
        algoritmos[i].funcao(copia, tamanho);
        fim = clock();

        tempoGasto = (double) (fim - inicio) / CLOCKS_PER_SEC;

        printf("%-18s %12.6f %10s\n",
               algoritmos[i].nome,
               tempoGasto,
               estaOrdenado(copia, tamanho) ? "OK" : "FALHOU");
    }

    free(original);
    free(copia);
}

static void exibirMenu(void) {
    printf("\n=== Trabalho de Algoritmos de Ordenacao ===\n");
    printf("1. Rodar exemplo simples (bubble sort)\n");
    printf("2. Rodar benchmark com todos os algoritmos (n=%d)\n", TAM_PADRAO);
    printf("3. Rodar benchmark com tamanho customizado\n");
    printf("0. Sair\n");
    printf("Escolha: ");
}

int main(int argc, char *argv[]) {
    int opcao;

    /* Permite rodar direto via linha de comando: ./sort_main bench */
    if (argc > 1 && strcmp(argv[1], "bench") == 0) {
        executarBenchmark(TAM_PADRAO);
        return 0;
    }

    do {
        exibirMenu();
        if (scanf("%d", &opcao) != 1) {
            break;
        }

        switch (opcao) {
            case 1: {
                int v[] = {5, 2, 9, 1, 5, 6, 3};
                int n = sizeof(v) / sizeof(v[0]);

                printf("Antes:  ");
                imprimirVetor(v, n);

                bubbleSort(v, n);

                printf("Depois: ");
                imprimirVetor(v, n);
                break;
            }
            case 2:
                executarBenchmark(TAM_PADRAO);
                break;
            case 3: {
                int tamanho;
                printf("Digite o tamanho do vetor: ");
                if (scanf("%d", &tamanho) == 1 && tamanho > 0) {
                    executarBenchmark(tamanho);
                }
                break;
            }
            case 0:
                printf("Encerrando...\n");
                break;
            default:
                printf("Opcao invalida.\n");
        }
    } while (opcao != 0);

    return 0;
}
