#ifndef SORT_H
#define SORT_H

/* Algoritmos básicos */
void bubbleSort(int v[], int n);
void selectionSort(int v[], int n);
void insertionSort(int v[], int n);

/* Algoritmos avançados */
void mergeSort(int v[], int n);
void quickSort(int v[], int n);
void heapSort(int v[], int n);

#endif /* SORT_H */
