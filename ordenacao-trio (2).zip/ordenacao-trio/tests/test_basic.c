#include <stdio.h>
#include <string.h>
#include "../src/sort.h"

static int totalTestes = 0;
static int testesPassou = 0;

static int estaOrdenado(const int v[], int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        if (v[i] > v[i + 1]) {
            return 0;
        }
    }
    return 1;
}

static void rodarCaso(const char *nomeAlgoritmo, void (*funcao)(int[], int),
                       const char *nomeCaso, int v[], int n) {
    totalTestes++;
    funcao(v, n);

    if (estaOrdenado(v, n)) {
        testesPassou++;
        printf("  [%s] %-22s ... \xE2\x9C\x93 PASSOU\n", nomeAlgoritmo, nomeCaso);
    } else {
        printf("  [%s] %-22s ... \xE2\x9C\x97 FALHOU\n", nomeAlgoritmo, nomeCaso);
    }
}

/*
 * Para cada algoritmo testamos:
 *  1) vetor aleatório (caso geral)
 *  2) vetor já ordenado (melhor caso para alguns algoritmos)
 *  3) vetor invertido (pior caso para alguns algoritmos)
 *  4) casos de borda: n=0, n=1, vetor com duplicatas
 */
static void testarAlgoritmo(const char *nome, void (*funcao)(int[], int)) {
    int aleatorio[] = {38, 27, 43, 3, 9, 82, 10, 1, 67, 25};
    int ordenado[]  = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int invertido[] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int duplicatas[] = {5, 3, 5, 1, 3, 5, 1, 1};
    int umElemento[] = {42};
    int vazio[1] = {0};

    printf("\n--- %s ---\n", nome);

    rodarCaso(nome, funcao, "vetor aleatorio",
              aleatorio, sizeof(aleatorio) / sizeof(aleatorio[0]));
    rodarCaso(nome, funcao, "vetor ja ordenado",
              ordenado, sizeof(ordenado) / sizeof(ordenado[0]));
    rodarCaso(nome, funcao, "vetor invertido",
              invertido, sizeof(invertido) / sizeof(invertido[0]));
    rodarCaso(nome, funcao, "vetor com duplicatas",
              duplicatas, sizeof(duplicatas) / sizeof(duplicatas[0]));
    rodarCaso(nome, funcao, "um elemento (n=1)",
              umElemento, 1);
    rodarCaso(nome, funcao, "vetor vazio (n=0)",
              vazio, 0);
}

int main(void) {
    printf("=== Suite de Testes - Algoritmos de Ordenacao ===\n");

    testarAlgoritmo("Bubble Sort",    bubbleSort);
    testarAlgoritmo("Selection Sort", selectionSort);
    testarAlgoritmo("Insertion Sort", insertionSort);
    testarAlgoritmo("Merge Sort",     mergeSort);
    testarAlgoritmo("Quick Sort",     quickSort);
    testarAlgoritmo("Heap Sort",      heapSort);

    printf("\n===================================\n");
    printf("Resultado: %d/%d testes passaram\n", testesPassou, totalTestes);
    printf("===================================\n");

    return (testesPassou == totalTestes) ? 0 : 1;
}
